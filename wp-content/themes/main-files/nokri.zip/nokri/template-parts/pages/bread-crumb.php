 <?php global $nokri; 
$bg_url = '';
if ( isset( $nokri['breadcrumb_img'] ) )
{
	$bg_url = nokri_getBGStyle('breadcrumb_img');
}

 ?>

 
 
 
 
 
 
 
 
 
 
 
 
 
 

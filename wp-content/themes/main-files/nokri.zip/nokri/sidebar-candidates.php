<?php
 if ( is_active_sidebar( 'candidates_sidebar' ) )
{  dynamic_sidebar('candidates_sidebar');  }
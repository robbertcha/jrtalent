<?php  if ( is_active_sidebar( 'employers_sidebar' ) )
{  dynamic_sidebar('employers_sidebar');  }
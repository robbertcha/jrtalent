<?php  if ( is_active_sidebar( 'shop_sidebar' ) )
{  dynamic_sidebar('shop_sidebar');  }
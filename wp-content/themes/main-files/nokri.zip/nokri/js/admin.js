 jQuery(document).ready(function($){ 
 "use strict";
 $('.my-color-field').wpColorPicker();
 }); 